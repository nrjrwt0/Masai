    function Plants(name){
      this.canspeak = false;
      this.move = false;
      this.name = name;
    }

    function Animals(name){
      this.canspeak = true;
      this.move = false;
      this.name = name;
    }

    function Humans(name){
      this.canspeak = true;
      this.move = false;
      this.name = name;
    }

    var plantsArr = [];
    var animalsArr = [];
    var humansArr = [];

    var plantsNames = ["Neem","Mango","Banyan","Papaya","Pears","Sal"];
    var animalsNames = ["dog","cat","cow","rabbit","horse","pig"];
    var humansName = ["Neeraj","Tina","Rahul","Sneha","Ram","Sita"];
    var startP = 0;
    
    setInterval(function(){
      var plant = new Plants(plantsNames[startP]);
      plantsArr.push(plant);
      console.log(plantsArr);
      startP++;
      if(startP > 5){
        startP = 0;
      }
    },6000)

    var startA = 0;
    setInterval(function(){
      var animal = new Animals(animalsNames[startA]);
      animalsArr.push(animal);
      console.log(animalsArr);

      startA++;
      if(startA > 5){
        startA = 0;
      }
    },10000)

    var startH = 0;
    setInterval(function(){
      var human = new Humans(humansName[startH]);
      humansArr.push(human);
      console.log(humansArr);

      startH++;
      if(startH > 5){
        startH = 0;
      }
    },15000)


    //OPTIONAL
    //Removing or Death of Plant Animals or Humans

    setInterval(function(){
      plantsArr.pop();
      console.log(plantsArr);
    },14000);

    setInterval(function(){
      animalsArr.pop();
      console.log(animalsArr);
    },24000)

    setInterval(function(){
      humansArr.pop();
      console.log(humansArr);
    },34000)
